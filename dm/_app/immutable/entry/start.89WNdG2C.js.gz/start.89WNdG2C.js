import{a as t}from"../chunks/entry.Ddvz1fjk.js";export{t as start};
